﻿<meta charset="utf-8" />
<?php
echo read_file_docx("files/file2.docx");